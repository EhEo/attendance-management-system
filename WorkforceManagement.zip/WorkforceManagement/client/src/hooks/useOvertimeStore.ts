import { create } from 'zustand';
import { Employee } from '@shared/schema';

interface OvertimeStore {
  selectedEmployees: Employee[];
  addEmployee: (employee: Employee) => void;
  removeEmployee: (employeeId: number) => void;
  clearSelection: () => void;
}

export const useOvertimeStore = create<OvertimeStore>((set) => ({
  selectedEmployees: [],
  
  addEmployee: (employee) =>
    set((state) => ({
      selectedEmployees: state.selectedEmployees.some(e => e.id === employee.id)
        ? state.selectedEmployees
        : [...state.selectedEmployees, employee],
    })),
  
  removeEmployee: (employeeId) =>
    set((state) => ({
      selectedEmployees: state.selectedEmployees.filter(e => e.id !== employeeId),
    })),
  
  clearSelection: () =>
    set({ selectedEmployees: [] }),
}));
