import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { USER_ROLES, ROLE_LABELS } from "@/lib/constants";
import { 
  Clock, 
  Gauge, 
  CheckCircle, 
  CalendarCheck, 
  BarChart3, 
  Calculator, 
  Bell, 
  Users, 
  Settings,
  LogOut
} from "lucide-react";

const menuItems = [
  { 
    key: 'dashboard', 
    icon: Gauge, 
    label: '대시보드', 
    path: '/',
    roles: ['all']
  },
  { 
    key: 'overtime', 
    icon: Clock, 
    label: '잔업신청', 
    path: '/overtime-request',
    roles: [USER_ROLES.DEPARTMENT_MANAGER, USER_ROLES.DEPARTMENT_LEADER, USER_ROLES.TEAM_MANAGER]
  },
  { 
    key: 'approval', 
    icon: CheckCircle, 
    label: '결재승인', 
    path: '/approval',
    roles: [USER_ROLES.DEPARTMENT_LEADER, USER_ROLES.TEAM_MANAGER, USER_ROLES.HR_STAFF, USER_ROLES.PRODUCTION_PLANNING]
  },
  { 
    key: 'attendance', 
    icon: CalendarCheck, 
    label: '근태확인', 
    path: '/attendance',
    roles: [USER_ROLES.HR_STAFF, USER_ROLES.DEPARTMENT_MANAGER]
  },
  { 
    key: 'reports', 
    icon: BarChart3, 
    label: '월간집계', 
    path: '/reports',
    roles: [USER_ROLES.HR_STAFF, USER_ROLES.DEPARTMENT_MANAGER]
  },
  { 
    key: 'payroll', 
    icon: Calculator, 
    label: '급여계산', 
    path: '/payroll',
    roles: [USER_ROLES.HR_STAFF]
  },
  { 
    key: 'notifications', 
    icon: Bell, 
    label: '알림관리', 
    path: '/notifications',
    roles: ['all']
  }
];

const adminMenuItems = [
  { 
    key: 'users', 
    icon: Users, 
    label: '사용자관리', 
    path: '/users',
    roles: [USER_ROLES.HR_STAFF]
  },
  { 
    key: 'settings', 
    icon: Settings, 
    label: '시스템설정', 
    path: '/settings',
    roles: [USER_ROLES.HR_STAFF]
  }
];

export default function Sidebar() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const userRole = user?.role || USER_ROLES.VIEWER;
  const userInitials = user?.firstName && user?.lastName 
    ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
    : user?.email?.substring(0, 2).toUpperCase() || 'U';

  const canAccessMenuItem = (item: typeof menuItems[0]) => {
    return item.roles.includes('all') || item.roles.includes(userRole);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="w-64 bg-surface shadow-lg border-r border-border flex flex-col">
      {/* Logo Area */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Clock className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-medium text-foreground">근태관리</h1>
            <p className="text-sm text-muted-foreground">시스템</p>
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-medium">{userInitials}</span>
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || 'User'
              }
            </p>
            <p className="text-xs text-muted-foreground">
              {ROLE_LABELS[userRole as keyof typeof ROLE_LABELS] || '사용자'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          {menuItems.filter(canAccessMenuItem).map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path || 
              (item.path !== '/' && location.startsWith(item.path));
            
            return (
              <button
                key={item.key}
                onClick={() => setLocation(item.path)}
                className={`flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg w-full text-left transition-colors ${
                  isActive
                    ? 'text-white bg-primary'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
                {item.key === 'notifications' && (
                  <span className="ml-auto bg-error text-white text-xs px-2 py-1 rounded-full">3</span>
                )}
              </button>
            );
          })}
        </div>
        
        {/* Admin Section */}
        {adminMenuItems.some(canAccessMenuItem) && (
          <div className="pt-4 border-t border-border">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">관리자</p>
            {adminMenuItems.filter(canAccessMenuItem).map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path || 
                (item.path !== '/' && location.startsWith(item.path));
              
              return (
                <button
                  key={item.key}
                  onClick={() => setLocation(item.path)}
                  className={`flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg w-full text-left transition-colors ${
                    isActive
                      ? 'text-white bg-primary'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-border">
        <button
          onClick={handleLogout}
          className="flex items-center space-x-3 px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground rounded-lg w-full transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>로그아웃</span>
        </button>
      </div>
    </div>
  );
}
