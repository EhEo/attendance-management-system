import { Calendar, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface HeaderProps {
  title: string;
  breadcrumb: BreadcrumbItem[];
}

export default function Header({ title, breadcrumb }: HeaderProps) {
  const currentDate = new Date().toLocaleDateString('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <header className="bg-surface shadow-sm border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">{title}</h2>
          <nav className="text-sm text-muted-foreground mt-1">
            {breadcrumb.map((item, index) => (
              <span key={index}>
                {index > 0 && (
                  <span className="mx-2">
                    <svg className="w-3 h-3 inline" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                )}
                <span className={index === breadcrumb.length - 1 ? 'text-primary' : ''}>
                  {item.label}
                </span>
              </span>
            ))}
          </nav>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Current Date */}
          <div className="text-sm text-muted-foreground">
            <Calendar className="w-4 h-4 inline mr-2" />
            <span>{currentDate}</span>
          </div>
          
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 bg-error text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
              3
            </span>
          </Button>
        </div>
      </div>
    </header>
  );
}
