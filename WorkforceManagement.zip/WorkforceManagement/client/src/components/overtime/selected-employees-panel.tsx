import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X, Send, Save } from "lucide-react";
import { useOvertimeStore } from "@/hooks/useOvertimeStore";
import { OVERTIME_REASONS } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function SelectedEmployeesPanel() {
  const [startTime, setStartTime] = useState("18:00");
  const [endTime, setEndTime] = useState("21:00");
  const [reason, setReason] = useState("");
  const [departmentId, setDepartmentId] = useState<number | null>(null);
  
  const { selectedEmployees, removeEmployee, clearSelection } = useOvertimeStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/overtime-requests", data);
    },
    onSuccess: () => {
      toast({
        title: "잔업 신청 완료",
        description: "잔업 신청이 성공적으로 제출되었습니다.",
      });
      clearSelection();
      setStartTime("18:00");
      setEndTime("21:00");
      setReason("");
      queryClient.invalidateQueries({ queryKey: ["/api/overtime-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "잔업 신청 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const calculateTotalHours = () => {
    if (!startTime || !endTime) return 0;
    const start = new Date(`2000-01-01T${startTime}:00`);
    const end = new Date(`2000-01-01T${endTime}:00`);
    const diffInMs = end.getTime() - start.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    return Math.max(0, diffInHours);
  };

  const calculateEstimatedCost = () => {
    const totalHours = calculateTotalHours();
    const hourlyRate = 15000; // Base hourly rate for overtime
    return totalHours * selectedEmployees.length * hourlyRate;
  };

  const handleSubmit = () => {
    if (selectedEmployees.length === 0) {
      toast({
        title: "직원 선택 필요",
        description: "잔업 신청할 직원을 선택해주세요.",
        variant: "destructive",
      });
      return;
    }

    if (!startTime || !endTime || !reason) {
      toast({
        title: "필수 정보 입력",
        description: "시작시간, 종료시간, 잔업사유를 모두 입력해주세요.",
        variant: "destructive",
      });
      return;
    }

    if (calculateTotalHours() <= 0) {
      toast({
        title: "시간 오류",
        description: "종료시간이 시작시간보다 늦어야 합니다.",
        variant: "destructive",
      });
      return;
    }

    // Get department ID from first selected employee
    const firstEmployeeDeptId = selectedEmployees[0]?.departmentId;
    if (!firstEmployeeDeptId) {
      toast({
        title: "부서 정보 오류",
        description: "직원의 부서 정보를 찾을 수 없습니다.",
        variant: "destructive",
      });
      return;
    }

    const today = new Date().toISOString().split('T')[0];

    const requestData = {
      departmentId: firstEmployeeDeptId,
      requestDate: today,
      overtimeDate: today,
      startTime,
      endTime,
      reason,
      employeeIds: selectedEmployees.map(emp => emp.id)
    };

    submitMutation.mutate(requestData);
  };

  const totalHours = calculateTotalHours();
  const estimatedCost = calculateEstimatedCost();

  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium text-foreground mb-4">
          잔업 신청 현황
        </CardTitle>
        
        {/* Overtime Details Form */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-foreground mb-2">시작 시간</Label>
              <Input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            
            <div>
              <Label className="text-sm font-medium text-foreground mb-2">종료 시간</Label>
              <Input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-foreground mb-2">잔업 사유</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger>
                <SelectValue placeholder="사유를 선택하세요" />
              </SelectTrigger>
              <SelectContent>
                {OVERTIME_REASONS.map((reasonOption) => (
                  <SelectItem key={reasonOption.value} value={reasonOption.value}>
                    {reasonOption.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      {/* Selected Employees List */}
      <CardContent className="flex-1 overflow-y-auto">
        <div className="mb-4">
          <p className="text-sm font-medium text-foreground">
            선택된 직원 ({selectedEmployees.length}명)
          </p>
        </div>
        
        {selectedEmployees.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <div className="w-12 h-12 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="w-6 h-6" />
            </div>
            <p>선택된 직원이 없습니다</p>
            <p className="text-xs mt-1">왼쪽에서 직원을 선택해주세요</p>
          </div>
        ) : (
          <div className="space-y-3">
            {selectedEmployees.map((employee) => {
              const initials = `${employee.firstName.charAt(0)}${employee.lastName.charAt(0)}`;
              
              return (
                <div
                  key={employee.id}
                  className="flex items-center justify-between p-4 border border-border rounded-lg bg-muted/30"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <span className="text-primary font-medium text-sm">{initials}</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {employee.firstName} {employee.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        사번: {employee.employeeNumber}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {startTime} - {endTime} ({totalHours}시간)
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeEmployee(employee.id)}
                    className="text-error hover:bg-error hover:text-white transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
      
      {/* Summary & Submit */}
      {selectedEmployees.length > 0 && (
        <div className="p-4 border-t border-border">
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-primary">총 잔업시간:</span>
              <span className="font-medium text-primary">
                {(totalHours * selectedEmployees.length).toFixed(1)}시간
              </span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span className="text-primary">예상 잔업비:</span>
              <span className="font-medium text-primary">
                ₩{estimatedCost.toLocaleString()}
              </span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Button
              className="flex-1 bg-primary hover:bg-primary/90"
              onClick={handleSubmit}
              disabled={submitMutation.isPending}
            >
              <Send className="w-4 h-4 mr-2" />
              {submitMutation.isPending ? "신청 중..." : "잔업 신청"}
            </Button>
            <Button variant="outline" disabled={submitMutation.isPending}>
              <Save className="w-4 h-4 mr-2" />
              임시저장
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
