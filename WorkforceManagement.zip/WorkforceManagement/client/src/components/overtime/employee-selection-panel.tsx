import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Search, CheckSquare, X } from "lucide-react";
import { useOvertimeStore } from "@/hooks/useOvertimeStore";

export default function EmployeeSelectionPanel() {
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const { selectedEmployees, addEmployee, removeEmployee, clearSelection } = useOvertimeStore();

  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    retry: false,
  });

  const { data: employees, isLoading: employeesLoading } = useQuery({
    queryKey: ["/api/employees", { departmentId: selectedDepartment }],
    enabled: !!selectedDepartment,
    retry: false,
  });

  const filteredEmployees = employees?.filter((employee: any) => {
    if (!searchTerm) return true;
    const searchLower = searchTerm.toLowerCase();
    return (
      employee.firstName.toLowerCase().includes(searchLower) ||
      employee.lastName.toLowerCase().includes(searchLower) ||
      employee.employeeNumber.toLowerCase().includes(searchLower)
    );
  }) || [];

  const handleEmployeeToggle = (employee: any, checked: boolean) => {
    if (checked) {
      addEmployee(employee);
    } else {
      removeEmployee(employee.id);
    }
  };

  const handleSelectAll = () => {
    filteredEmployees.forEach((employee: any) => {
      if (!selectedEmployees.some(selected => selected.id === employee.id)) {
        addEmployee(employee);
      }
    });
  };

  const getEmployeeStatus = (employee: any) => {
    // Mock status for demo - in real app this would come from attendance data
    const statuses = ['정상근무', '잔업중', '휴가'];
    const statusColors = ['success', 'warning', 'muted'];
    const randomIndex = employee.id % 3;
    return {
      label: statuses[randomIndex],
      color: statusColors[randomIndex]
    };
  };

  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium text-foreground mb-4">
          부서별 직원 선택
        </CardTitle>
        
        {/* Department Selection */}
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-foreground mb-2">부서 선택</Label>
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="부서를 선택하세요" />
              </SelectTrigger>
              <SelectContent>
                {departments?.map((dept: any) => (
                  <SelectItem key={dept.id} value={dept.id.toString()}>
                    {dept.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="직원 이름 또는 사번으로 검색"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </CardHeader>
      
      {/* Employee List */}
      <CardContent className="flex-1 overflow-y-auto">
        {!selectedDepartment ? (
          <div className="text-center py-8 text-muted-foreground">
            부서를 선택해주세요
          </div>
        ) : employeesLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-2 text-sm text-muted-foreground">직원 목록 로딩 중...</p>
          </div>
        ) : filteredEmployees.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            {searchTerm ? "검색 결과가 없습니다" : "직원이 없습니다"}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredEmployees.map((employee: any) => {
              const isSelected = selectedEmployees.some(selected => selected.id === employee.id);
              const status = getEmployeeStatus(employee);
              
              return (
                <label
                  key={employee.id}
                  className="flex items-center p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                >
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={(checked) => handleEmployeeToggle(employee, checked as boolean)}
                    className="mr-3"
                  />
                  <div className="flex-1">
                    <p className="font-medium text-foreground">
                      {employee.firstName} {employee.lastName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      사번: {employee.employeeNumber}
                    </p>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${
                      status.color === 'success' 
                        ? 'bg-success/10 text-success border-success' 
                        : status.color === 'warning'
                        ? 'bg-warning/10 text-warning border-warning'
                        : 'bg-muted/10 text-muted-foreground border-muted'
                    }`}
                  >
                    {status.label}
                  </Badge>
                </label>
              );
            })}
          </div>
        )}
      </CardContent>
      
      {/* Bulk Selection Actions */}
      {selectedDepartment && filteredEmployees.length > 0 && (
        <div className="p-4 border-t border-border">
          <div className="flex space-x-2">
            <Button
              variant="outline"
              className="flex-1 text-primary border-primary hover:bg-primary hover:text-white"
              onClick={handleSelectAll}
            >
              <CheckSquare className="w-4 h-4 mr-2" />
              전체 선택
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={clearSelection}
            >
              <X className="w-4 h-4 mr-2" />
              선택 해제
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
