export const USER_ROLES = {
  DEPARTMENT_MANAGER: 'department_manager',
  DEPARTMENT_LEADER: 'department_leader', 
  TEAM_MANAGER: 'team_manager',
  HR_STAFF: 'hr_staff',
  PRODUCTION_PLANNING: 'production_planning',
  VIEWER: 'viewer'
} as const;

export const ROLE_LABELS = {
  [USER_ROLES.DEPARTMENT_MANAGER]: '부문담당자',
  [USER_ROLES.DEPARTMENT_LEADER]: '부문리더',
  [USER_ROLES.TEAM_MANAGER]: '팀장',
  [USER_ROLES.HR_STAFF]: '인사담당',
  [USER_ROLES.PRODUCTION_PLANNING]: '생산계획담당',
  [USER_ROLES.VIEWER]: '조회권한'
} as const;

export const OVERTIME_REASONS = [
  { value: 'production', label: '생산량 증대' },
  { value: 'urgent', label: '긴급 주문 처리' },
  { value: 'maintenance', label: '설비 점검' },
  { value: 'quality', label: '품질 검사' },
  { value: 'other', label: '기타' }
];

export const SHIFTS = {
  DAY: 'day',
  NIGHT: 'night'
} as const;

export const SHIFT_LABELS = {
  [SHIFTS.DAY]: '주간',
  [SHIFTS.NIGHT]: '야간'
} as const;

export const OVERTIME_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved', 
  REJECTED: 'rejected',
  COMPLETED: 'completed'
} as const;

export const ATTENDANCE_STATUS = {
  UNVERIFIED: 'unverified',
  VERIFIED: 'verified',
  ANOMALY: 'anomaly'
} as const;

export const ANOMALY_TYPES = {
  LATE: 'late',
  EARLY_LEAVE: 'early_leave', 
  ABSENT: 'absent',
  OVERTIME_MISMATCH: 'overtime_mismatch'
} as const;

export const NOTIFICATION_TYPES = {
  OVERTIME_REQUEST: 'overtime_request',
  APPROVAL_NEEDED: 'approval_needed',
  ANOMALY_DETECTED: 'anomaly_detected',
  PAYROLL_READY: 'payroll_ready'
} as const;
