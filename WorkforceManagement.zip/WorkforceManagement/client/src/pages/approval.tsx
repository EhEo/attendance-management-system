import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, X, Edit, Clock, User, Calendar } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";

export default function Approval() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  const { data: pendingApprovals, isLoading: approvalsLoading, error } = useQuery({
    queryKey: ["/api/approvals/pending"],
    retry: false,
  });

  const approveMutation = useMutation({
    mutationFn: async ({ approvalId, status, comments }: { approvalId: number; status: string; comments?: string }) => {
      await apiRequest("PATCH", `/api/approvals/${approvalId}`, { status, comments });
    },
    onSuccess: () => {
      toast({
        title: "승인 처리 완료",
        description: "승인이 성공적으로 처리되었습니다.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/approvals/pending"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "승인 처리 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  const handleApproval = (approvalId: number, status: "approved" | "rejected") => {
    approveMutation.mutate({ approvalId, status });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="결재승인" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "결재승인" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {approvalsLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4 text-muted-foreground">승인 대기 목록을 불러오는 중...</p>
              </div>
            ) : !pendingApprovals || pendingApprovals.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">승인 대기 중인 항목이 없습니다</h3>
                  <p className="text-muted-foreground">모든 잔업 신청이 처리되었습니다.</p>
                </CardContent>
              </Card>
            ) : (
              pendingApprovals.map((approval: any) => (
                <Card key={approval.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        <Clock className="w-5 h-5" />
                        <span>잔업 신청 승인 요청</span>
                      </CardTitle>
                      <Badge variant="outline" className="text-warning border-warning">
                        승인 대기
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Approval Details */}
                      <div className="bg-muted/50 border border-border rounded-lg p-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">신청일시:</span>
                            <span className="text-sm font-medium">
                              {new Date(approval.createdAt).toLocaleDateString('ko-KR')} {new Date(approval.createdAt).toLocaleTimeString('ko-KR')}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">승인자 역할:</span>
                            <span className="text-sm font-medium">{approval.approverRole}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex space-x-3">
                        <Button 
                          className="flex-1 bg-success hover:bg-success/90"
                          onClick={() => handleApproval(approval.id, "approved")}
                          disabled={approveMutation.isPending}
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          승인
                        </Button>
                        <Button 
                          variant="destructive"
                          className="flex-1"
                          onClick={() => handleApproval(approval.id, "rejected")}
                          disabled={approveMutation.isPending}
                        >
                          <X className="w-4 h-4 mr-2" />
                          반려
                        </Button>
                        <Button variant="outline" disabled={approveMutation.isPending}>
                          <Edit className="w-4 h-4 mr-2" />
                          수정요청
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
