import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, DollarSign, FileText, Download } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Payroll() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="급여계산" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "급여계산" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {/* Payroll Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                      <DollarSign className="text-success w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">이번 달 총 급여</p>
                    <p className="text-2xl font-semibold text-foreground">₩847,250,000</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                      <Calculator className="text-warning w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">잔업비</p>
                    <p className="text-2xl font-semibold text-foreground">₩127,500,000</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <FileText className="text-primary w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">처리 완료</p>
                    <p className="text-2xl font-semibold text-foreground">1,247명</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payroll Calculation Process */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calculator className="w-5 h-5" />
                <span>급여 계산 프로세스</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Process Steps */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-success text-white rounded-full flex items-center justify-center text-sm font-medium">
                      ✓
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-foreground">1단계: 월간 근태 집계 완료</p>
                      <p className="text-xs text-muted-foreground">모든 부서 근태 데이터 확정</p>
                    </div>
                  </div>
                  <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">완료</span>
                </div>
                
                <div className="flex-1 h-px bg-success mx-4"></div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-success text-white rounded-full flex items-center justify-center text-sm font-medium">
                      ✓
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-foreground">2단계: 급여 기준 적용</p>
                      <p className="text-xs text-muted-foreground">시간당 급여, 잔업수당 계산</p>
                    </div>
                  </div>
                  <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">완료</span>
                </div>
                
                <div className="flex-1 h-px bg-warning mx-4"></div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-warning text-white rounded-full flex items-center justify-center text-sm font-medium">
                      3
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-foreground">3단계: 급여 계산 실행</p>
                      <p className="text-xs text-muted-foreground">최종 급여액 산출</p>
                    </div>
                  </div>
                  <span className="text-xs bg-warning/10 text-warning px-2 py-1 rounded-full">진행중</span>
                </div>
                
                <div className="flex-1 h-px bg-muted mx-4"></div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-muted text-muted-foreground rounded-full flex items-center justify-center text-sm font-medium">
                      4
                    </div>
                    <div className="ml-3">
                      <p className="text-sm font-medium text-muted-foreground">4단계: 급여 명세서 생성</p>
                      <p className="text-xs text-muted-foreground">개별 급여 명세서 작성</p>
                    </div>
                  </div>
                  <span className="text-xs bg-muted/10 text-muted-foreground px-2 py-1 rounded-full">대기</span>
                </div>
              </div>
              
              <div className="flex space-x-3 mt-6">
                <Button className="flex-1">
                  <Calculator className="w-4 h-4 mr-2" />
                  급여 계산 실행
                </Button>
                <Button variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  계산 내역 확인
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Payroll Summary Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5" />
                  <span>부서별 급여 현황</span>
                </CardTitle>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  급여 대장 다운로드
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-medium">부서</th>
                      <th className="text-right py-3 px-4 font-medium">인원</th>
                      <th className="text-right py-3 px-4 font-medium">기본급</th>
                      <th className="text-right py-3 px-4 font-medium">잔업수당</th>
                      <th className="text-right py-3 px-4 font-medium">총 급여</th>
                      <th className="text-center py-3 px-4 font-medium">상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4 font-medium">생산1부</td>
                      <td className="text-right py-3 px-4">287명</td>
                      <td className="text-right py-3 px-4">₩195,340,000</td>
                      <td className="text-right py-3 px-4">₩32,450,000</td>
                      <td className="text-right py-3 px-4 font-semibold">₩227,790,000</td>
                      <td className="text-center py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
                          계산완료
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4 font-medium">생산2부</td>
                      <td className="text-right py-3 px-4">294명</td>
                      <td className="text-right py-3 px-4">₩201,230,000</td>
                      <td className="text-right py-3 px-4">₩28,670,000</td>
                      <td className="text-right py-3 px-4 font-semibold">₩229,900,000</td>
                      <td className="text-center py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
                          계산완료
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4 font-medium">품질관리부</td>
                      <td className="text-right py-3 px-4">156명</td>
                      <td className="text-right py-3 px-4">₩134,670,000</td>
                      <td className="text-right py-3 px-4">₩18,230,000</td>
                      <td className="text-right py-3 px-4 font-semibold">₩152,900,000</td>
                      <td className="text-center py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-warning">
                          계산중
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4 font-medium">설비관리부</td>
                      <td className="text-right py-3 px-4">142명</td>
                      <td className="text-right py-3 px-4">₩123,450,000</td>
                      <td className="text-right py-3 px-4">₩21,340,000</td>
                      <td className="text-right py-3 px-4 font-semibold">₩144,790,000</td>
                      <td className="text-center py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-muted/10 text-muted-foreground">
                          대기중
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4 font-medium">물류부</td>
                      <td className="text-right py-3 px-4">89명</td>
                      <td className="text-right py-3 px-4">€67,890,000</td>
                      <td className="text-right py-3 px-4">₩9,780,000</td>
                      <td className="text-right py-3 px-4 font-semibold">₩77,670,000</td>
                      <td className="text-center py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-muted/10 text-muted-foreground">
                          대기중
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
