import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StatsCard from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Users, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: stats, isLoading: statsLoading, error } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (error && isUnauthorizedError(error)) {
    return null; // Will redirect via useEffect
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="대시보드" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "대시보드" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <StatsCard
              title="전체 직원"
              value={statsLoading ? "..." : stats?.totalEmployees?.toLocaleString() || "0"}
              unit="명"
              icon={<Users className="w-5 h-5" />}
              iconBgColor="bg-primary/10"
              iconColor="text-primary"
            />
            
            <StatsCard
              title="금일 잔업신청"
              value={statsLoading ? "..." : stats?.todayOvertime?.toString() || "0"}
              unit="명"
              icon={<Clock className="w-5 h-5" />}
              iconBgColor="bg-warning/10"
              iconColor="text-warning"
            />
            
            <StatsCard
              title="승인 완료"
              value={statsLoading ? "..." : stats?.approvedCount?.toString() || "0"}
              unit="명"
              icon={<CheckCircle className="w-5 h-5" />}
              iconBgColor="bg-success/10"
              iconColor="text-success"
            />
            
            <StatsCard
              title="승인 대기"
              value={statsLoading ? "..." : stats?.pendingCount?.toString() || "0"}
              unit="명"
              icon={<AlertTriangle className="w-5 h-5" />}
              iconBgColor="bg-destructive/10"
              iconColor="text-destructive"
            />
          </div>

          {/* Content Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>최근 잔업 신청</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">생산1부 - 3명</p>
                      <p className="text-sm text-muted-foreground">18:00 - 21:00 (3시간)</p>
                    </div>
                    <span className="text-xs bg-warning/10 text-warning px-2 py-1 rounded-full">승인대기</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">품질관리부 - 2명</p>
                      <p className="text-sm text-muted-foreground">19:00 - 22:00 (3시간)</p>
                    </div>
                    <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">승인완료</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">설비관리부 - 1명</p>
                      <p className="text-sm text-muted-foreground">20:00 - 23:00 (3시간)</p>
                    </div>
                    <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">승인완료</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span>근태 이상 알림</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">지각 - 김철수</p>
                      <p className="text-sm text-muted-foreground">생산1부 | 30분 지각</p>
                    </div>
                    <span className="text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">미확인</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">조퇴 - 박영희</p>
                      <p className="text-sm text-muted-foreground">품질관리부 | 1시간 조퇴</p>
                    </div>
                    <span className="text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">미확인</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium">잔업시간 불일치 - 정수진</p>
                      <p className="text-sm text-muted-foreground">생산2부 | 신청 3시간 vs 실제 2시간</p>
                    </div>
                    <span className="text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">미확인</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
