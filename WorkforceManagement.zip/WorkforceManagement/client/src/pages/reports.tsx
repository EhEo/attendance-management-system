import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, Calendar, Download, FileText } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Reports() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const { data: monthlyData, isLoading: monthlyLoading, error } = useQuery({
    queryKey: ["/api/monthly-summary", { year: currentYear, month: currentMonth }],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="월간집계" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "월간집계" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {/* Filter Controls */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>조회 기간 설정</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">년도:</label>
                  <Select defaultValue={currentYear.toString()}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024">2024년</SelectItem>
                      <SelectItem value="2023">2023년</SelectItem>
                      <SelectItem value="2022">2022년</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">월:</label>
                  <Select defaultValue={currentMonth.toString()}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => (
                        <SelectItem key={i + 1} value={(i + 1).toString()}>
                          {i + 1}월
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <Button>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  조회
                </Button>
                
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  엑셀 다운로드
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Summary Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <FileText className="text-primary w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">총 근무시간</p>
                    <p className="text-2xl font-semibold text-foreground">1,247시간</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                      <Calendar className="text-warning w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">총 잔업시간</p>
                    <p className="text-2xl font-semibold text-foreground">342시간</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                      <BarChart3 className="text-success w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">평균 출근율</p>
                    <p className="text-2xl font-semibold text-foreground">97.2%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
                      <Calendar className="text-destructive w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">지각/조퇴</p>
                    <p className="text-2xl font-semibold text-foreground">23건</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Monthly Summary Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5" />
                <span>월간 근태 집계</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {monthlyLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-4 text-muted-foreground">월간 집계를 불러오는 중...</p>
                </div>
              ) : !monthlyData || monthlyData.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">집계 데이터가 없습니다</h3>
                  <p className="text-muted-foreground">선택한 기간의 집계 데이터가 아직 생성되지 않았습니다.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-medium">직원</th>
                        <th className="text-left py-3 px-4 font-medium">부서</th>
                        <th className="text-right py-3 px-4 font-medium">정규시간</th>
                        <th className="text-right py-3 px-4 font-medium">잔업시간</th>
                        <th className="text-right py-3 px-4 font-medium">지각</th>
                        <th className="text-right py-3 px-4 font-medium">조퇴</th>
                        <th className="text-right py-3 px-4 font-medium">결근</th>
                        <th className="text-center py-3 px-4 font-medium">상태</th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthlyData.slice(0, 20).map((summary: any, index: number) => (
                        <tr key={summary.id || index} className="border-b border-border hover:bg-muted/50">
                          <td className="py-3 px-4">직원 {summary.employeeId}</td>
                          <td className="py-3 px-4">부서명</td>
                          <td className="text-right py-3 px-4">{summary.totalRegularHours}시간</td>
                          <td className="text-right py-3 px-4">{summary.totalOvertimeHours}시간</td>
                          <td className="text-right py-3 px-4">{summary.totalLateCount}회</td>
                          <td className="text-right py-3 px-4">{summary.totalEarlyLeaveCount}회</td>
                          <td className="text-right py-3 px-4">{summary.totalAbsentCount}회</td>
                          <td className="text-center py-3 px-4">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              summary.isFinalized 
                                ? 'bg-success/10 text-success' 
                                : 'bg-warning/10 text-warning'
                            }`}>
                              {summary.isFinalized ? '확정' : '미확정'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
