import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import EmployeeSelectionPanel from "@/components/overtime/employee-selection-panel";
import SelectedEmployeesPanel from "@/components/overtime/selected-employees-panel";
import StatsCard from "@/components/ui/stats-card";
import { useQuery } from "@tanstack/react-query";
import { Users, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function OvertimeRequest() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: stats, isLoading: statsLoading, error } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="잔업신청" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "잔업신청" }]}
        />
        
        <main className="flex-1 overflow-hidden p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <StatsCard
              title="전체 직원"
              value={statsLoading ? "..." : stats?.totalEmployees?.toLocaleString() || "0"}
              unit="명"
              icon={<Users className="w-5 h-5" />}
              iconBgColor="bg-primary/10"
              iconColor="text-primary"
            />
            
            <StatsCard
              title="금일 잔업신청"
              value={statsLoading ? "..." : stats?.todayOvertime?.toString() || "0"}
              unit="명"
              icon={<Clock className="w-5 h-5" />}
              iconBgColor="bg-warning/10"
              iconColor="text-warning"
            />
            
            <StatsCard
              title="승인 완료"
              value={statsLoading ? "..." : stats?.approvedCount?.toString() || "0"}
              unit="명"
              icon={<CheckCircle className="w-5 h-5" />}
              iconBgColor="bg-success/10"
              iconColor="text-success"
            />
            
            <StatsCard
              title="승인 대기"
              value={statsLoading ? "..." : stats?.pendingCount?.toString() || "0"}
              unit="명"
              icon={<AlertTriangle className="w-5 h-5" />}
              iconBgColor="bg-destructive/10"
              iconColor="text-destructive"
            />
          </div>

          {/* Two-Panel Interface */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-300px)]">
            <EmployeeSelectionPanel />
            <SelectedEmployeesPanel />
          </div>
        </main>
      </div>
    </div>
  );
}
