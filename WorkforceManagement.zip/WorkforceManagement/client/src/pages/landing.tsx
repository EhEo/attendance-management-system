import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, Users, CheckCircle, Calculator } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center">
              <Clock className="text-white text-2xl" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">
            근태관리 및 급여계산 시스템
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            1,000명 규모의 제조업체를 위한 통합 근태관리 솔루션
          </p>
          <Button 
            size="lg" 
            onClick={() => window.location.href = "/api/login"}
            className="text-lg px-8 py-3"
          >
            시스템 로그인
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="text-primary text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">직원 관리</h3>
              <p className="text-sm text-muted-foreground">
                부서별 직원 현황 및 2조 2교대 관리
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock className="text-warning text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">잔업 신청</h3>
              <p className="text-sm text-muted-foreground">
                부서별 잔업 신청 및 승인 워크플로우
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-success text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">근태 확인</h3>
              <p className="text-sm text-muted-foreground">
                지문인식 기록 대조 및 이상 근태 관리
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-error/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Calculator className="text-error text-xl" />
              </div>
              <h3 className="text-lg font-semibold mb-2">급여 계산</h3>
              <p className="text-sm text-muted-foreground">
                월간 근태 집계 및 급여 계산 자동화
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>© 2024 근태관리 시스템. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
