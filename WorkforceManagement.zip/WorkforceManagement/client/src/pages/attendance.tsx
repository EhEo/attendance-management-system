import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { CalendarCheck, AlertTriangle, Clock, User } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function Attendance() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: unverifiedRecords, isLoading: recordsLoading, error } = useQuery({
    queryKey: ["/api/attendance/unverified"],
    retry: false,
  });

  const { data: anomalies, isLoading: anomaliesLoading } = useQuery({
    queryKey: ["/api/attendance/anomalies"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="근태확인" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "근태확인" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Unverified Attendance Records */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CalendarCheck className="w-5 h-5" />
                  <span>미확인 근태 기록</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recordsLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                      <p className="mt-2 text-sm text-muted-foreground">로딩 중...</p>
                    </div>
                  ) : !unverifiedRecords || unverifiedRecords.length === 0 ? (
                    <div className="text-center py-8">
                      <CalendarCheck className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">미확인 근태 기록이 없습니다.</p>
                    </div>
                  ) : (
                    unverifiedRecords.slice(0, 10).map((record: any) => (
                      <div key={record.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                            <User className="w-4 h-4 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">직원 ID: {record.employeeId}</p>
                            <p className="text-sm text-muted-foreground">
                              {record.attendanceDate} | {record.checkInTime} - {record.checkOutTime}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="text-warning border-warning">
                            미확인
                          </Badge>
                          <Button size="sm" variant="outline">
                            확인
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Attendance Anomalies */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span>근태 이상 알림</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {anomaliesLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                      <p className="mt-2 text-sm text-muted-foreground">로딩 중...</p>
                    </div>
                  ) : !anomalies || anomalies.length === 0 ? (
                    <div className="text-center py-8">
                      <AlertTriangle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">근태 이상이 없습니다.</p>
                    </div>
                  ) : (
                    anomalies.slice(0, 10).map((anomaly: any) => (
                      <div key={anomaly.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-destructive/10 rounded-full flex items-center justify-center">
                            <AlertTriangle className="w-4 h-4 text-destructive" />
                          </div>
                          <div>
                            <p className="font-medium">{anomaly.anomalyType} - 기록 ID: {anomaly.attendanceRecordId}</p>
                            <p className="text-sm text-muted-foreground">{anomaly.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            variant="outline" 
                            className={anomaly.isResolved ? "text-success border-success" : "text-destructive border-destructive"}
                          >
                            {anomaly.isResolved ? "해결됨" : "미해결"}
                          </Badge>
                          {!anomaly.isResolved && (
                            <Button size="sm" variant="outline">
                              해결
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Daily Attendance Verification */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>일일 근태 확인</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">일일 근태 확인 기능</h3>
                <p className="text-muted-foreground mb-4">
                  지문인식 시스템과 연동하여 매일 오전 출퇴근 기록을 확인합니다.
                </p>
                <Button>
                  <Clock className="w-4 h-4 mr-2" />
                  금일 근태 확인 시작
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
