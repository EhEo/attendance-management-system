import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Settings, Building, Plus, Database, Clock, Shield, UserCheck } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { USER_ROLES } from "@/lib/constants";

export default function SettingsPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();
  const [isCreateDeptDialogOpen, setIsCreateDeptDialogOpen] = useState(false);

  // Only HR staff can access this page
  const canAccess = user?.role === USER_ROLES.HR_STAFF;

  const { data: departments, isLoading: departmentsLoading, error } = useQuery({
    queryKey: ["/api/departments"],
    retry: false,
    enabled: canAccess,
  });

  const createDepartmentMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/departments", data);
    },
    onSuccess: () => {
      toast({
        title: "부서 생성 완료",
        description: "새 부서가 성공적으로 생성되었습니다.",
      });
      setIsCreateDeptDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/departments"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "부서 생성 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!isLoading && isAuthenticated && !canAccess) {
      toast({
        title: "접근 권한 없음",
        description: "이 페이지에 접근할 권한이 없습니다.",
        variant: "destructive",
      });
      return;
    }
  }, [isAuthenticated, isLoading, canAccess, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!canAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-xl font-semibold text-foreground mb-2">접근 권한 없음</h1>
            <p className="text-muted-foreground">
              이 페이지는 인사담당자만 접근할 수 있습니다.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleCreateDepartment = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const departmentData = {
      name: formData.get('name'),
      code: formData.get('code'),
    };

    createDepartmentMutation.mutate(departmentData);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="시스템설정" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "관리자" }, { label: "시스템설정" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto space-y-6">
            {/* System Information */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Database className="text-primary w-4 h-4" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">시스템 버전</p>
                      <p className="text-lg font-semibold text-foreground">v1.0.0</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                        <Clock className="text-success w-4 h-4" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">서버 상태</p>
                      <p className="text-lg font-semibold text-success">정상</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                        <UserCheck className="text-warning w-4 h-4" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">접속 사용자</p>
                      <p className="text-lg font-semibold text-foreground">23명</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Department Management */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Building className="w-5 h-5" />
                    <span>부서 관리</span>
                  </CardTitle>
                  <Dialog open={isCreateDeptDialogOpen} onOpenChange={setIsCreateDeptDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        새 부서 추가
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>새 부서 추가</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleCreateDepartment} className="space-y-4">
                        <div>
                          <Label htmlFor="name">부서명</Label>
                          <Input id="name" name="name" placeholder="예: 생산1부" required />
                        </div>
                        
                        <div>
                          <Label htmlFor="code">부서코드</Label>
                          <Input id="code" name="code" placeholder="예: PROD01" required />
                        </div>
                        
                        <div className="flex space-x-2 pt-4">
                          <Button type="submit" className="flex-1" disabled={createDepartmentMutation.isPending}>
                            {createDepartmentMutation.isPending ? "생성 중..." : "생성"}
                          </Button>
                          <Button type="button" variant="outline" onClick={() => setIsCreateDeptDialogOpen(false)}>
                            취소
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {departmentsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                    <p className="mt-2 text-sm text-muted-foreground">부서 목록을 불러오는 중...</p>
                  </div>
                ) : !departments || departments.length === 0 ? (
                  <div className="text-center py-8">
                    <Building className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">등록된 부서가 없습니다</h3>
                    <p className="text-muted-foreground">새 부서를 추가해보세요.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 font-medium">부서명</th>
                          <th className="text-left py-3 px-4 font-medium">부서코드</th>
                          <th className="text-left py-3 px-4 font-medium">담당자</th>
                          <th className="text-left py-3 px-4 font-medium">리더</th>
                          <th className="text-center py-3 px-4 font-medium">생성일</th>
                        </tr>
                      </thead>
                      <tbody>
                        {departments.map((department: any) => (
                          <tr key={department.id} className="border-b border-border hover:bg-muted/50">
                            <td className="py-3 px-4 font-medium">{department.name}</td>
                            <td className="py-3 px-4 font-mono text-sm">{department.code}</td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {department.managerId || '미배정'}
                            </td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {department.leaderId || '미배정'}
                            </td>
                            <td className="text-center py-3 px-4 text-sm text-muted-foreground">
                              {new Date(department.createdAt).toLocaleDateString('ko-KR')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* System Settings */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* General Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="w-5 h-5" />
                    <span>일반 설정</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">자동 백업</Label>
                      <p className="text-xs text-muted-foreground">매일 자동으로 데이터를 백업합니다</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">이메일 알림</Label>
                      <p className="text-xs text-muted-foreground">중요한 알림을 이메일로 전송합니다</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">기본 근무시간</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs text-muted-foreground">시작시간</Label>
                        <Input type="time" defaultValue="09:00" />
                      </div>
                      <div>
                        <Label className="text-xs text-muted-foreground">종료시간</Label>
                        <Input type="time" defaultValue="18:00" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Security Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-5 h-5" />
                    <span>보안 설정</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">2단계 인증</Label>
                      <p className="text-xs text-muted-foreground">로그인 시 추가 인증을 요구합니다</p>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">세션 타임아웃</Label>
                      <p className="text-xs text-muted-foreground">비활성 시 자동 로그아웃됩니다</p>
                    </div>
                    <Select defaultValue="30">
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15분</SelectItem>
                        <SelectItem value="30">30분</SelectItem>
                        <SelectItem value="60">1시간</SelectItem>
                        <SelectItem value="120">2시간</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">접근 로그</Label>
                      <p className="text-xs text-muted-foreground">모든 사용자 접근을 기록합니다</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button className="px-8">
                <Settings className="w-4 h-4 mr-2" />
                설정 저장
              </Button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
