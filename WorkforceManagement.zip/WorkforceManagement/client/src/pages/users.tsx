import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, Plus, Edit, Search, UserCheck, Building } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { USER_ROLES, ROLE_LABELS, SHIFT_LABELS } from "@/lib/constants";

export default function UsersPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRole, setSelectedRole] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Only HR staff can access this page
  const canAccess = user?.role === USER_ROLES.HR_STAFF;

  const { data: employees, isLoading: employeesLoading, error } = useQuery({
    queryKey: ["/api/employees"],
    retry: false,
    enabled: canAccess,
  });

  const { data: departments } = useQuery({
    queryKey: ["/api/departments"],
    retry: false,
    enabled: canAccess,
  });

  const createEmployeeMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/employees", data);
    },
    onSuccess: () => {
      toast({
        title: "직원 등록 완료",
        description: "새 직원이 성공적으로 등록되었습니다.",
      });
      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "직원 등록 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (!isLoading && isAuthenticated && !canAccess) {
      toast({
        title: "접근 권한 없음",
        description: "이 페이지에 접근할 권한이 없습니다.",
        variant: "destructive",
      });
      return;
    }
  }, [isAuthenticated, isLoading, canAccess, toast]);

  if (error && isUnauthorizedError(error)) {
    return null;
  }

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!canAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <UserCheck className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-xl font-semibold text-foreground mb-2">접근 권한 없음</h1>
            <p className="text-muted-foreground">
              이 페이지는 인사담당자만 접근할 수 있습니다.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredEmployees = employees?.filter((employee: any) => {
    const matchesSearch = !searchTerm || 
      employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.employeeNumber.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = !selectedRole || employee.position === selectedRole;
    
    return matchesSearch && matchesRole;
  }) || [];

  const handleCreateEmployee = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const employeeData = {
      employeeNumber: formData.get('employeeNumber'),
      firstName: formData.get('firstName'),
      lastName: formData.get('lastName'),
      departmentId: parseInt(formData.get('departmentId') as string),
      position: formData.get('position'),
      shift: formData.get('shift'),
      isActive: true
    };

    createEmployeeMutation.mutate(employeeData);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="사용자관리" 
          breadcrumb={[{ label: "홈", href: "/" }, { label: "관리자" }, { label: "사용자관리" }]}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {/* Header Actions */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="직원 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="직책으로 필터" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">전체</SelectItem>
                  <SelectItem value="기술자">기술자</SelectItem>
                  <SelectItem value="작업자">작업자</SelectItem>
                  <SelectItem value="팀장">팀장</SelectItem>
                  <SelectItem value="관리자">관리자</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  새 직원 등록
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>새 직원 등록</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateEmployee} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">성</Label>
                      <Input id="firstName" name="firstName" required />
                    </div>
                    <div>
                      <Label htmlFor="lastName">이름</Label>
                      <Input id="lastName" name="lastName" required />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="employeeNumber">사번</Label>
                    <Input id="employeeNumber" name="employeeNumber" required />
                  </div>
                  
                  <div>
                    <Label htmlFor="departmentId">부서</Label>
                    <Select name="departmentId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="부서 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments?.map((dept: any) => (
                          <SelectItem key={dept.id} value={dept.id.toString()}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="position">직책</Label>
                    <Select name="position" required>
                      <SelectTrigger>
                        <SelectValue placeholder="직책 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="작업자">작업자</SelectItem>
                        <SelectItem value="기술자">기술자</SelectItem>
                        <SelectItem value="팀장">팀장</SelectItem>
                        <SelectItem value="관리자">관리자</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="shift">근무조</Label>
                    <Select name="shift" required>
                      <SelectTrigger>
                        <SelectValue placeholder="근무조 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="day">주간</SelectItem>
                        <SelectItem value="night">야간</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex space-x-2 pt-4">
                    <Button type="submit" className="flex-1" disabled={createEmployeeMutation.isPending}>
                      {createEmployeeMutation.isPending ? "등록 중..." : "등록"}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                      취소
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Employee Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Users className="text-primary w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">전체 직원</p>
                    <p className="text-2xl font-semibold text-foreground">
                      {employees?.length || 0}명
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                      <UserCheck className="text-success w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">활성 직원</p>
                    <p className="text-2xl font-semibold text-foreground">
                      {employees?.filter((e: any) => e.isActive).length || 0}명
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                      <Building className="text-warning w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">부서 수</p>
                    <p className="text-2xl font-semibold text-foreground">
                      {departments?.length || 0}개
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Users className="text-primary w-4 h-4" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-muted-foreground">평균 부서 인원</p>
                    <p className="text-2xl font-semibold text-foreground">
                      {departments?.length ? Math.round((employees?.length || 0) / departments.length) : 0}명
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Employee List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>직원 목록</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {employeesLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-4 text-muted-foreground">직원 목록을 불러오는 중...</p>
                </div>
              ) : filteredEmployees.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    {searchTerm || selectedRole ? "검색 결과가 없습니다" : "등록된 직원이 없습니다"}
                  </h3>
                  <p className="text-muted-foreground">
                    {searchTerm || selectedRole ? "다른 검색 조건을 시도해보세요" : "새 직원을 등록해보세요"}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-medium">직원</th>
                        <th className="text-left py-3 px-4 font-medium">사번</th>
                        <th className="text-left py-3 px-4 font-medium">부서</th>
                        <th className="text-left py-3 px-4 font-medium">직책</th>
                        <th className="text-left py-3 px-4 font-medium">근무조</th>
                        <th className="text-center py-3 px-4 font-medium">상태</th>
                        <th className="text-center py-3 px-4 font-medium">작업</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredEmployees.map((employee: any) => {
                        const department = departments?.find((d: any) => d.id === employee.departmentId);
                        
                        return (
                          <tr key={employee.id} className="border-b border-border hover:bg-muted/50">
                            <td className="py-3 px-4">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                                  <span className="text-primary font-medium text-xs">
                                    {employee.firstName.charAt(0)}{employee.lastName.charAt(0)}
                                  </span>
                                </div>
                                <span className="font-medium">
                                  {employee.firstName} {employee.lastName}
                                </span>
                              </div>
                            </td>
                            <td className="py-3 px-4 font-mono text-sm">{employee.employeeNumber}</td>
                            <td className="py-3 px-4">{department?.name || '미배정'}</td>
                            <td className="py-3 px-4">{employee.position || '미정'}</td>
                            <td className="py-3 px-4">
                              <Badge variant="outline">
                                {SHIFT_LABELS[employee.shift as keyof typeof SHIFT_LABELS] || employee.shift}
                              </Badge>
                            </td>
                            <td className="text-center py-3 px-4">
                              <Badge 
                                variant="outline"
                                className={employee.isActive 
                                  ? "bg-success/10 text-success border-success" 
                                  : "bg-muted/10 text-muted-foreground"
                                }
                              >
                                {employee.isActive ? '활성' : '비활성'}
                              </Badge>
                            </td>
                            <td className="text-center py-3 px-4">
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
