import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertOvertimeRequestSchema,
  insertApprovalSchema,
  insertAttendanceRecordSchema,
  insertAttendanceAnomalySchema,
  insertNotificationSchema,
  insertDepartmentSchema,
  insertTeamSchema,
  insertEmployeeSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Department routes
  app.get('/api/departments', isAuthenticated, async (req: any, res) => {
    try {
      const departments = await storage.getDepartments();
      res.json(departments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      res.status(500).json({ message: "Failed to fetch departments" });
    }
  });

  app.post('/api/departments', isAuthenticated, async (req: any, res) => {
    try {
      const departmentData = insertDepartmentSchema.parse(req.body);
      const department = await storage.createDepartment(departmentData);
      res.json(department);
    } catch (error) {
      console.error("Error creating department:", error);
      res.status(500).json({ message: "Failed to create department" });
    }
  });

  // Team routes
  app.get('/api/teams', isAuthenticated, async (req: any, res) => {
    try {
      const { departmentId } = req.query;
      const teams = departmentId 
        ? await storage.getTeamsByDepartment(parseInt(departmentId))
        : await storage.getTeams();
      res.json(teams);
    } catch (error) {
      console.error("Error fetching teams:", error);
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  // Employee routes
  app.get('/api/employees', isAuthenticated, async (req: any, res) => {
    try {
      const { departmentId } = req.query;
      const employees = departmentId 
        ? await storage.getEmployeesByDepartment(parseInt(departmentId))
        : await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.post('/api/employees', isAuthenticated, async (req: any, res) => {
    try {
      const employeeData = insertEmployeeSchema.parse(req.body);
      const employee = await storage.createEmployee(employeeData);
      res.json(employee);
    } catch (error) {
      console.error("Error creating employee:", error);
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  // Overtime request routes
  app.get('/api/overtime-requests', isAuthenticated, async (req: any, res) => {
    try {
      const { departmentId } = req.query;
      const userId = req.user.claims.sub;
      
      let requests;
      if (departmentId) {
        requests = await storage.getOvertimeRequestsByDepartment(parseInt(departmentId));
      } else {
        requests = await storage.getOvertimeRequestsByRequester(userId);
      }
      
      res.json(requests);
    } catch (error) {
      console.error("Error fetching overtime requests:", error);
      res.status(500).json({ message: "Failed to fetch overtime requests" });
    }
  });

  app.get('/api/overtime-requests/pending', isAuthenticated, async (req: any, res) => {
    try {
      const requests = await storage.getPendingOvertimeRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching pending overtime requests:", error);
      res.status(500).json({ message: "Failed to fetch pending overtime requests" });
    }
  });

  app.get('/api/overtime-requests/:id/employees', isAuthenticated, async (req: any, res) => {
    try {
      const requestId = parseInt(req.params.id);
      const employees = await storage.getOvertimeRequestEmployees(requestId);
      res.json(employees);
    } catch (error) {
      console.error("Error fetching overtime request employees:", error);
      res.status(500).json({ message: "Failed to fetch overtime request employees" });
    }
  });

  app.post('/api/overtime-requests', isAuthenticated, async (req: any, res) => {
    try {
      const { employeeIds, ...requestData } = req.body;
      const overtimeData = insertOvertimeRequestSchema.parse({
        ...requestData,
        requesterId: req.user.claims.sub
      });
      
      const request = await storage.createOvertimeRequest(overtimeData, employeeIds);
      
      // Create notifications for approvers
      // TODO: Implement notification logic based on approval workflow
      
      res.json(request);
    } catch (error) {
      console.error("Error creating overtime request:", error);
      res.status(500).json({ message: "Failed to create overtime request" });
    }
  });

  app.patch('/api/overtime-requests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const requestId = parseInt(req.params.id);
      const updateData = req.body;
      const request = await storage.updateOvertimeRequest(requestId, updateData);
      res.json(request);
    } catch (error) {
      console.error("Error updating overtime request:", error);
      res.status(500).json({ message: "Failed to update overtime request" });
    }
  });

  // Approval routes
  app.get('/api/approvals/pending', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const approvals = await storage.getPendingApprovals(userId);
      res.json(approvals);
    } catch (error) {
      console.error("Error fetching pending approvals:", error);
      res.status(500).json({ message: "Failed to fetch pending approvals" });
    }
  });

  app.get('/api/approvals/request/:requestId', isAuthenticated, async (req: any, res) => {
    try {
      const requestId = parseInt(req.params.requestId);
      const approvals = await storage.getApprovalsByRequest(requestId);
      res.json(approvals);
    } catch (error) {
      console.error("Error fetching approvals:", error);
      res.status(500).json({ message: "Failed to fetch approvals" });
    }
  });

  app.post('/api/approvals', isAuthenticated, async (req: any, res) => {
    try {
      const approvalData = insertApprovalSchema.parse({
        ...req.body,
        approverId: req.user.claims.sub
      });
      const approval = await storage.createApproval(approvalData);
      res.json(approval);
    } catch (error) {
      console.error("Error creating approval:", error);
      res.status(500).json({ message: "Failed to create approval" });
    }
  });

  app.patch('/api/approvals/:id', isAuthenticated, async (req: any, res) => {
    try {
      const approvalId = parseInt(req.params.id);
      const updateData = req.body;
      const approval = await storage.updateApproval(approvalId, updateData);
      res.json(approval);
    } catch (error) {
      console.error("Error updating approval:", error);
      res.status(500).json({ message: "Failed to update approval" });
    }
  });

  // Attendance routes
  app.get('/api/attendance', isAuthenticated, async (req: any, res) => {
    try {
      const { employeeId, dateFrom, dateTo } = req.query;
      const records = await storage.getAttendanceRecords(
        employeeId ? parseInt(employeeId) : undefined,
        dateFrom as string,
        dateTo as string
      );
      res.json(records);
    } catch (error) {
      console.error("Error fetching attendance records:", error);
      res.status(500).json({ message: "Failed to fetch attendance records" });
    }
  });

  app.get('/api/attendance/unverified', isAuthenticated, async (req: any, res) => {
    try {
      const records = await storage.getUnverifiedAttendanceRecords();
      res.json(records);
    } catch (error) {
      console.error("Error fetching unverified attendance records:", error);
      res.status(500).json({ message: "Failed to fetch unverified attendance records" });
    }
  });

  app.post('/api/attendance', isAuthenticated, async (req: any, res) => {
    try {
      const recordData = insertAttendanceRecordSchema.parse(req.body);
      const record = await storage.createAttendanceRecord(recordData);
      res.json(record);
    } catch (error) {
      console.error("Error creating attendance record:", error);
      res.status(500).json({ message: "Failed to create attendance record" });
    }
  });

  app.patch('/api/attendance/:id', isAuthenticated, async (req: any, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const updateData = {
        ...req.body,
        verifiedBy: req.user.claims.sub
      };
      const record = await storage.updateAttendanceRecord(recordId, updateData);
      res.json(record);
    } catch (error) {
      console.error("Error updating attendance record:", error);
      res.status(500).json({ message: "Failed to update attendance record" });
    }
  });

  // Attendance anomaly routes
  app.get('/api/attendance/anomalies', isAuthenticated, async (req: any, res) => {
    try {
      const { isResolved } = req.query;
      const anomalies = await storage.getAttendanceAnomalies(
        isResolved !== undefined ? isResolved === 'true' : undefined
      );
      res.json(anomalies);
    } catch (error) {
      console.error("Error fetching attendance anomalies:", error);
      res.status(500).json({ message: "Failed to fetch attendance anomalies" });
    }
  });

  app.post('/api/attendance/anomalies', isAuthenticated, async (req: any, res) => {
    try {
      const anomalyData = insertAttendanceAnomalySchema.parse(req.body);
      const anomaly = await storage.createAttendanceAnomaly(anomalyData);
      res.json(anomaly);
    } catch (error) {
      console.error("Error creating attendance anomaly:", error);
      res.status(500).json({ message: "Failed to create attendance anomaly" });
    }
  });

  app.patch('/api/attendance/anomalies/:id', isAuthenticated, async (req: any, res) => {
    try {
      const anomalyId = parseInt(req.params.id);
      const updateData = {
        ...req.body,
        resolvedBy: req.user.claims.sub
      };
      const anomaly = await storage.updateAttendanceAnomaly(anomalyId, updateData);
      res.json(anomaly);
    } catch (error) {
      console.error("Error updating attendance anomaly:", error);
      res.status(500).json({ message: "Failed to update attendance anomaly" });
    }
  });

  // Monthly summary routes
  app.get('/api/monthly-summary', isAuthenticated, async (req: any, res) => {
    try {
      const { employeeId, year, month } = req.query;
      const summaries = await storage.getMonthlyAttendanceSummary(
        employeeId ? parseInt(employeeId) : undefined,
        year ? parseInt(year) : undefined,
        month ? parseInt(month) : undefined
      );
      res.json(summaries);
    } catch (error) {
      console.error("Error fetching monthly attendance summary:", error);
      res.status(500).json({ message: "Failed to fetch monthly attendance summary" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { isRead } = req.query;
      const notifications = await storage.getNotifications(
        userId,
        isRead !== undefined ? isRead === 'true' : undefined
      );
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      const notification = await storage.markNotificationAsRead(notificationId);
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
