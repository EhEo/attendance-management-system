import {
  users,
  departments,
  teams,
  employees,
  overtimeRequests,
  overtimeRequestEmployees,
  approvals,
  attendanceRecords,
  attendanceAnomalies,
  monthlyAttendanceSummary,
  notifications,
  type User,
  type UpsertUser,
  type Department,
  type Team,
  type Employee,
  type OvertimeRequest,
  type OvertimeRequestEmployee,
  type Approval,
  type AttendanceRecord,
  type AttendanceAnomaly,
  type MonthlyAttendanceSummary,
  type Notification,
  type InsertDepartment,
  type InsertTeam,
  type InsertEmployee,
  type InsertOvertimeRequest,
  type InsertOvertimeRequestEmployee,
  type InsertApproval,
  type InsertAttendanceRecord,
  type InsertAttendanceAnomaly,
  type InsertMonthlyAttendanceSummary,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, gte, lte, like, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Department operations
  getDepartments(): Promise<Department[]>;
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department>;

  // Team operations
  getTeams(): Promise<Team[]>;
  getTeamsByDepartment(departmentId: number): Promise<Team[]>;
  createTeam(team: InsertTeam): Promise<Team>;

  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployeesByDepartment(departmentId: number): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee>;

  // Overtime request operations
  getOvertimeRequests(): Promise<OvertimeRequest[]>;
  getOvertimeRequestsByRequester(requesterId: string): Promise<OvertimeRequest[]>;
  getOvertimeRequestsByDepartment(departmentId: number): Promise<OvertimeRequest[]>;
  getPendingOvertimeRequests(): Promise<OvertimeRequest[]>;
  getOvertimeRequest(id: number): Promise<OvertimeRequest | undefined>;
  createOvertimeRequest(request: InsertOvertimeRequest, employeeIds: number[]): Promise<OvertimeRequest>;
  updateOvertimeRequest(id: number, request: Partial<InsertOvertimeRequest>): Promise<OvertimeRequest>;

  // Overtime request employee operations
  getOvertimeRequestEmployees(requestId: number): Promise<OvertimeRequestEmployee[]>;
  updateOvertimeRequestEmployee(id: number, data: Partial<InsertOvertimeRequestEmployee>): Promise<OvertimeRequestEmployee>;

  // Approval operations
  getApprovalsByRequest(requestId: number): Promise<Approval[]>;
  getPendingApprovals(approverId: string): Promise<Approval[]>;
  createApproval(approval: InsertApproval): Promise<Approval>;
  updateApproval(id: number, approval: Partial<InsertApproval>): Promise<Approval>;

  // Attendance operations
  getAttendanceRecords(employeeId?: number, dateFrom?: string, dateTo?: string): Promise<AttendanceRecord[]>;
  getUnverifiedAttendanceRecords(): Promise<AttendanceRecord[]>;
  createAttendanceRecord(record: InsertAttendanceRecord): Promise<AttendanceRecord>;
  updateAttendanceRecord(id: number, record: Partial<InsertAttendanceRecord>): Promise<AttendanceRecord>;

  // Attendance anomaly operations
  getAttendanceAnomalies(isResolved?: boolean): Promise<AttendanceAnomaly[]>;
  createAttendanceAnomaly(anomaly: InsertAttendanceAnomaly): Promise<AttendanceAnomaly>;
  updateAttendanceAnomaly(id: number, anomaly: Partial<InsertAttendanceAnomaly>): Promise<AttendanceAnomaly>;

  // Monthly summary operations
  getMonthlyAttendanceSummary(employeeId?: number, year?: number, month?: number): Promise<MonthlyAttendanceSummary[]>;
  createMonthlyAttendanceSummary(summary: InsertMonthlyAttendanceSummary): Promise<MonthlyAttendanceSummary>;
  updateMonthlyAttendanceSummary(employeeId: number, year: number, month: number, summary: Partial<InsertMonthlyAttendanceSummary>): Promise<MonthlyAttendanceSummary>;

  // Notification operations
  getNotifications(userId: string, isRead?: boolean): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification>;

  // Dashboard statistics
  getDashboardStats(): Promise<{
    totalEmployees: number;
    todayOvertime: number;
    approvedCount: number;
    pendingCount: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Department operations
  async getDepartments(): Promise<Department[]> {
    return await db.select().from(departments).orderBy(asc(departments.name));
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    const [department] = await db.select().from(departments).where(eq(departments.id, id));
    return department;
  }

  async createDepartment(department: InsertDepartment): Promise<Department> {
    const [newDepartment] = await db.insert(departments).values(department).returning();
    return newDepartment;
  }

  async updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department> {
    const [updatedDepartment] = await db
      .update(departments)
      .set(department)
      .where(eq(departments.id, id))
      .returning();
    return updatedDepartment;
  }

  // Team operations
  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams).orderBy(asc(teams.name));
  }

  async getTeamsByDepartment(departmentId: number): Promise<Team[]> {
    return await db
      .select()
      .from(teams)
      .where(eq(teams.departmentId, departmentId))
      .orderBy(asc(teams.name));
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams).values(team).returning();
    return newTeam;
  }

  // Employee operations
  async getEmployees(): Promise<Employee[]> {
    return await db.select().from(employees).where(eq(employees.isActive, true)).orderBy(asc(employees.lastName));
  }

  async getEmployeesByDepartment(departmentId: number): Promise<Employee[]> {
    return await db
      .select()
      .from(employees)
      .where(and(eq(employees.departmentId, departmentId), eq(employees.isActive, true)))
      .orderBy(asc(employees.lastName));
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db.insert(employees).values(employee).returning();
    return newEmployee;
  }

  async updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee> {
    const [updatedEmployee] = await db
      .update(employees)
      .set(employee)
      .where(eq(employees.id, id))
      .returning();
    return updatedEmployee;
  }

  // Overtime request operations
  async getOvertimeRequests(): Promise<OvertimeRequest[]> {
    return await db.select().from(overtimeRequests).orderBy(desc(overtimeRequests.submittedAt));
  }

  async getOvertimeRequestsByRequester(requesterId: string): Promise<OvertimeRequest[]> {
    return await db
      .select()
      .from(overtimeRequests)
      .where(eq(overtimeRequests.requesterId, requesterId))
      .orderBy(desc(overtimeRequests.submittedAt));
  }

  async getOvertimeRequestsByDepartment(departmentId: number): Promise<OvertimeRequest[]> {
    return await db
      .select()
      .from(overtimeRequests)
      .where(eq(overtimeRequests.departmentId, departmentId))
      .orderBy(desc(overtimeRequests.submittedAt));
  }

  async getPendingOvertimeRequests(): Promise<OvertimeRequest[]> {
    return await db
      .select()
      .from(overtimeRequests)
      .where(eq(overtimeRequests.status, "pending"))
      .orderBy(desc(overtimeRequests.submittedAt));
  }

  async getOvertimeRequest(id: number): Promise<OvertimeRequest | undefined> {
    const [request] = await db.select().from(overtimeRequests).where(eq(overtimeRequests.id, id));
    return request;
  }

  async createOvertimeRequest(request: InsertOvertimeRequest, employeeIds: number[]): Promise<OvertimeRequest> {
    const [newRequest] = await db.insert(overtimeRequests).values(request).returning();

    // Create overtime request employees
    const requestEmployees = employeeIds.map(employeeId => ({
      overtimeRequestId: newRequest.id,
      employeeId,
    }));

    await db.insert(overtimeRequestEmployees).values(requestEmployees);

    return newRequest;
  }

  async updateOvertimeRequest(id: number, request: Partial<InsertOvertimeRequest>): Promise<OvertimeRequest> {
    const [updatedRequest] = await db
      .update(overtimeRequests)
      .set({ ...request, updatedAt: new Date() })
      .where(eq(overtimeRequests.id, id))
      .returning();
    return updatedRequest;
  }

  // Overtime request employee operations
  async getOvertimeRequestEmployees(requestId: number): Promise<OvertimeRequestEmployee[]> {
    return await db
      .select()
      .from(overtimeRequestEmployees)
      .where(eq(overtimeRequestEmployees.overtimeRequestId, requestId));
  }

  async updateOvertimeRequestEmployee(id: number, data: Partial<InsertOvertimeRequestEmployee>): Promise<OvertimeRequestEmployee> {
    const [updated] = await db
      .update(overtimeRequestEmployees)
      .set(data)
      .where(eq(overtimeRequestEmployees.id, id))
      .returning();
    return updated;
  }

  // Approval operations
  async getApprovalsByRequest(requestId: number): Promise<Approval[]> {
    return await db
      .select()
      .from(approvals)
      .where(eq(approvals.overtimeRequestId, requestId))
      .orderBy(asc(approvals.createdAt));
  }

  async getPendingApprovals(approverId: string): Promise<Approval[]> {
    return await db
      .select()
      .from(approvals)
      .where(and(eq(approvals.approverId, approverId), eq(approvals.status, "pending")))
      .orderBy(desc(approvals.createdAt));
  }

  async createApproval(approval: InsertApproval): Promise<Approval> {
    const [newApproval] = await db.insert(approvals).values(approval).returning();
    return newApproval;
  }

  async updateApproval(id: number, approval: Partial<InsertApproval>): Promise<Approval> {
    const updateData: any = { ...approval };
    if (approval.status === "approved" || approval.status === "rejected") {
      updateData.approvedAt = new Date();
    }

    const [updatedApproval] = await db
      .update(approvals)
      .set(updateData)
      .where(eq(approvals.id, id))
      .returning();
    return updatedApproval;
  }

  // Attendance operations
  async getAttendanceRecords(employeeId?: number, dateFrom?: string, dateTo?: string): Promise<AttendanceRecord[]> {
    let query = db.select().from(attendanceRecords);
    
    const conditions = [];
    if (employeeId) conditions.push(eq(attendanceRecords.employeeId, employeeId));
    if (dateFrom) conditions.push(gte(attendanceRecords.attendanceDate, dateFrom));
    if (dateTo) conditions.push(lte(attendanceRecords.attendanceDate, dateTo));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query;
  }

  async getUnverifiedAttendanceRecords(): Promise<AttendanceRecord[]> {
    return await db
      .select()
      .from(attendanceRecords)
      .where(eq(attendanceRecords.status, "unverified"))
      .orderBy(desc(attendanceRecords.attendanceDate));
  }

  async createAttendanceRecord(record: InsertAttendanceRecord): Promise<AttendanceRecord> {
    const [newRecord] = await db.insert(attendanceRecords).values(record).returning();
    return newRecord;
  }

  async updateAttendanceRecord(id: number, record: Partial<InsertAttendanceRecord>): Promise<AttendanceRecord> {
    const updateData: any = { ...record };
    if (record.status === "verified") {
      updateData.verifiedAt = new Date();
    }

    const [updatedRecord] = await db
      .update(attendanceRecords)
      .set(updateData)
      .where(eq(attendanceRecords.id, id))
      .returning();
    return updatedRecord;
  }

  // Attendance anomaly operations
  async getAttendanceAnomalies(isResolved?: boolean): Promise<AttendanceAnomaly[]> {
    let query = db.select().from(attendanceAnomalies);
    
    if (isResolved !== undefined) {
      query = query.where(eq(attendanceAnomalies.isResolved, isResolved));
    }

    return await query;
  }

  async createAttendanceAnomaly(anomaly: InsertAttendanceAnomaly): Promise<AttendanceAnomaly> {
    const [newAnomaly] = await db.insert(attendanceAnomalies).values(anomaly).returning();
    return newAnomaly;
  }

  async updateAttendanceAnomaly(id: number, anomaly: Partial<InsertAttendanceAnomaly>): Promise<AttendanceAnomaly> {
    const updateData: any = { ...anomaly };
    if (anomaly.isResolved) {
      updateData.resolvedAt = new Date();
    }

    const [updatedAnomaly] = await db
      .update(attendanceAnomalies)
      .set(updateData)
      .where(eq(attendanceAnomalies.id, id))
      .returning();
    return updatedAnomaly;
  }

  // Monthly summary operations
  async getMonthlyAttendanceSummary(employeeId?: number, year?: number, month?: number): Promise<MonthlyAttendanceSummary[]> {
    let query = db.select().from(monthlyAttendanceSummary);
    
    const conditions = [];
    if (employeeId) conditions.push(eq(monthlyAttendanceSummary.employeeId, employeeId));
    if (year) conditions.push(eq(monthlyAttendanceSummary.year, year));
    if (month) conditions.push(eq(monthlyAttendanceSummary.month, month));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query;
  }

  async createMonthlyAttendanceSummary(summary: InsertMonthlyAttendanceSummary): Promise<MonthlyAttendanceSummary> {
    const [newSummary] = await db.insert(monthlyAttendanceSummary).values(summary).returning();
    return newSummary;
  }

  async updateMonthlyAttendanceSummary(employeeId: number, year: number, month: number, summary: Partial<InsertMonthlyAttendanceSummary>): Promise<MonthlyAttendanceSummary> {
    const updateData: any = { ...summary };
    if (summary.isFinalized) {
      updateData.finalizedAt = new Date();
    }

    const [updatedSummary] = await db
      .update(monthlyAttendanceSummary)
      .set(updateData)
      .where(and(
        eq(monthlyAttendanceSummary.employeeId, employeeId),
        eq(monthlyAttendanceSummary.year, year),
        eq(monthlyAttendanceSummary.month, month)
      ))
      .returning();
    return updatedSummary;
  }

  // Notification operations
  async getNotifications(userId: string, isRead?: boolean): Promise<Notification[]> {
    let query = db.select().from(notifications).where(eq(notifications.userId, userId));
    
    if (isRead !== undefined) {
      query = db.select().from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.isRead, isRead)));
    }

    return await query.orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationAsRead(id: number): Promise<Notification> {
    const [updatedNotification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return updatedNotification;
  }

  // Dashboard statistics
  async getDashboardStats(): Promise<{
    totalEmployees: number;
    todayOvertime: number;
    approvedCount: number;
    pendingCount: number;
  }> {
    const today = new Date().toISOString().split('T')[0];

    const [totalEmployeesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(employees)
      .where(eq(employees.isActive, true));

    const [todayOvertimeResult] = await db
      .select({ count: sql<number>`count(distinct ${overtimeRequestEmployees.employeeId})` })
      .from(overtimeRequestEmployees)
      .innerJoin(overtimeRequests, eq(overtimeRequestEmployees.overtimeRequestId, overtimeRequests.id))
      .where(eq(overtimeRequests.overtimeDate, today));

    const [approvedCountResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(overtimeRequests)
      .where(and(eq(overtimeRequests.overtimeDate, today), eq(overtimeRequests.status, "approved")));

    const [pendingCountResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(overtimeRequests)
      .where(and(eq(overtimeRequests.overtimeDate, today), eq(overtimeRequests.status, "pending")));

    return {
      totalEmployees: totalEmployeesResult.count,
      todayOvertime: todayOvertimeResult.count,
      approvedCount: approvedCountResult.count,
      pendingCount: pendingCountResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
