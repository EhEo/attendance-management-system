import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  time,
  date,
  decimal,
  primaryKey,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("viewer"), // department_manager, department_leader, team_manager, hr_staff, production_planning, viewer
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Departments table
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  managerId: varchar("manager_id"),
  leaderId: varchar("leader_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Teams table
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  departmentId: integer("department_id").notNull(),
  managerId: varchar("manager_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Employees table
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  employeeNumber: varchar("employee_number", { length: 20 }).notNull().unique(),
  firstName: varchar("first_name", { length: 50 }).notNull(),
  lastName: varchar("last_name", { length: 50 }).notNull(),
  departmentId: integer("department_id").notNull(),
  teamId: integer("team_id"),
  position: varchar("position", { length: 100 }),
  shift: varchar("shift", { length: 10 }).notNull(), // day, night
  isActive: boolean("is_active").default(true),
  userId: varchar("user_id"), // Link to users table if employee has system access
  createdAt: timestamp("created_at").defaultNow(),
});

// Overtime requests table
export const overtimeRequests = pgTable("overtime_requests", {
  id: serial("id").primaryKey(),
  requesterId: varchar("requester_id").notNull(),
  departmentId: integer("department_id").notNull(),
  requestDate: date("request_date").notNull(),
  overtimeDate: date("overtime_date").notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  reason: varchar("reason", { length: 500 }).notNull(),
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected, completed
  submittedAt: timestamp("submitted_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Overtime request employees (many-to-many)
export const overtimeRequestEmployees = pgTable("overtime_request_employees", {
  id: serial("id").primaryKey(),
  overtimeRequestId: integer("overtime_request_id").notNull(),
  employeeId: integer("employee_id").notNull(),
  approvedHours: decimal("approved_hours", { precision: 4, scale: 2 }),
  actualStartTime: time("actual_start_time"),
  actualEndTime: time("actual_end_time"),
  actualHours: decimal("actual_hours", { precision: 4, scale: 2 }),
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected, completed
});

// Approval workflow table
export const approvals = pgTable("approvals", {
  id: serial("id").primaryKey(),
  overtimeRequestId: integer("overtime_request_id").notNull(),
  approverId: varchar("approver_id").notNull(),
  approverRole: varchar("approver_role").notNull(), // department_leader, team_manager, hr_staff, production_planning
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected
  comments: text("comments"),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Attendance records table (from fingerprint system)
export const attendanceRecords = pgTable("attendance_records", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  attendanceDate: date("attendance_date").notNull(),
  checkInTime: time("check_in_time"),
  checkOutTime: time("check_out_time"),
  isLate: boolean("is_late").default(false),
  isEarlyLeave: boolean("is_early_leave").default(false),
  isAbsent: boolean("is_absent").default(false),
  isVacation: boolean("is_vacation").default(false),
  overtimeHours: decimal("overtime_hours", { precision: 4, scale: 2 }).default("0"),
  regularHours: decimal("regular_hours", { precision: 4, scale: 2 }).default("0"),
  status: varchar("status").notNull().default("unverified"), // unverified, verified, anomaly
  verifiedBy: varchar("verified_by"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Attendance anomalies table
export const attendanceAnomalies = pgTable("attendance_anomalies", {
  id: serial("id").primaryKey(),
  attendanceRecordId: integer("attendance_record_id").notNull(),
  anomalyType: varchar("anomaly_type").notNull(), // late, early_leave, absent, overtime_mismatch
  description: text("description"),
  isResolved: boolean("is_resolved").default(false),
  resolvedBy: varchar("resolved_by"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Monthly attendance summary table
export const monthlyAttendanceSummary = pgTable("monthly_attendance_summary", {
  employeeId: integer("employee_id").notNull(),
  year: integer("year").notNull(),
  month: integer("month").notNull(),
  totalRegularHours: decimal("total_regular_hours", { precision: 8, scale: 2 }).default("0"),
  totalOvertimeHours: decimal("total_overtime_hours", { precision: 8, scale: 2 }).default("0"),
  totalLateCount: integer("total_late_count").default(0),
  totalEarlyLeaveCount: integer("total_early_leave_count").default(0),
  totalAbsentCount: integer("total_absent_count").default(0),
  totalVacationCount: integer("total_vacation_count").default(0),
  isFinalized: boolean("is_finalized").default(false),
  finalizedBy: varchar("finalized_by"),
  finalizedAt: timestamp("finalized_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  primaryKey({ columns: [table.employeeId, table.year, table.month] })
]);

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message").notNull(),
  type: varchar("type").notNull(), // overtime_request, approval_needed, anomaly_detected, payroll_ready
  relatedId: integer("related_id"), // Related entity ID (overtime request, attendance record, etc.)
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  notifications: many(notifications),
  overtimeRequests: many(overtimeRequests),
  approvals: many(approvals),
}));

export const departmentsRelations = relations(departments, ({ one, many }) => ({
  manager: one(users, {
    fields: [departments.managerId],
    references: [users.id],
  }),
  leader: one(users, {
    fields: [departments.leaderId],
    references: [users.id],
  }),
  teams: many(teams),
  employees: many(employees),
  overtimeRequests: many(overtimeRequests),
}));

export const teamsRelations = relations(teams, ({ one, many }) => ({
  department: one(departments, {
    fields: [teams.departmentId],
    references: [departments.id],
  }),
  manager: one(users, {
    fields: [teams.managerId],
    references: [users.id],
  }),
  employees: many(employees),
}));

export const employeesRelations = relations(employees, ({ one, many }) => ({
  department: one(departments, {
    fields: [employees.departmentId],
    references: [departments.id],
  }),
  team: one(teams, {
    fields: [employees.teamId],
    references: [teams.id],
  }),
  user: one(users, {
    fields: [employees.userId],
    references: [users.id],
  }),
  overtimeRequestEmployees: many(overtimeRequestEmployees),
  attendanceRecords: many(attendanceRecords),
  monthlyAttendanceSummary: many(monthlyAttendanceSummary),
}));

export const overtimeRequestsRelations = relations(overtimeRequests, ({ one, many }) => ({
  requester: one(users, {
    fields: [overtimeRequests.requesterId],
    references: [users.id],
  }),
  department: one(departments, {
    fields: [overtimeRequests.departmentId],
    references: [departments.id],
  }),
  overtimeRequestEmployees: many(overtimeRequestEmployees),
  approvals: many(approvals),
}));

export const overtimeRequestEmployeesRelations = relations(overtimeRequestEmployees, ({ one }) => ({
  overtimeRequest: one(overtimeRequests, {
    fields: [overtimeRequestEmployees.overtimeRequestId],
    references: [overtimeRequests.id],
  }),
  employee: one(employees, {
    fields: [overtimeRequestEmployees.employeeId],
    references: [employees.id],
  }),
}));

export const approvalsRelations = relations(approvals, ({ one }) => ({
  overtimeRequest: one(overtimeRequests, {
    fields: [approvals.overtimeRequestId],
    references: [overtimeRequests.id],
  }),
  approver: one(users, {
    fields: [approvals.approverId],
    references: [users.id],
  }),
}));

export const attendanceRecordsRelations = relations(attendanceRecords, ({ one, many }) => ({
  employee: one(employees, {
    fields: [attendanceRecords.employeeId],
    references: [employees.id],
  }),
  verifier: one(users, {
    fields: [attendanceRecords.verifiedBy],
    references: [users.id],
  }),
  anomalies: many(attendanceAnomalies),
}));

export const attendanceAnomaliesRelations = relations(attendanceAnomalies, ({ one }) => ({
  attendanceRecord: one(attendanceRecords, {
    fields: [attendanceAnomalies.attendanceRecordId],
    references: [attendanceRecords.id],
  }),
  resolver: one(users, {
    fields: [attendanceAnomalies.resolvedBy],
    references: [users.id],
  }),
}));

export const monthlyAttendanceSummaryRelations = relations(monthlyAttendanceSummary, ({ one }) => ({
  employee: one(employees, {
    fields: [monthlyAttendanceSummary.employeeId],
    references: [employees.id],
  }),
  finalizer: one(users, {
    fields: [monthlyAttendanceSummary.finalizedBy],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertDepartmentSchema = createInsertSchema(departments).omit({ id: true, createdAt: true });
export const insertTeamSchema = createInsertSchema(teams).omit({ id: true, createdAt: true });
export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true, createdAt: true });
export const insertOvertimeRequestSchema = createInsertSchema(overtimeRequests).omit({ 
  id: true, 
  submittedAt: true, 
  updatedAt: true 
});
export const insertOvertimeRequestEmployeeSchema = createInsertSchema(overtimeRequestEmployees).omit({ id: true });
export const insertApprovalSchema = createInsertSchema(approvals).omit({ 
  id: true, 
  approvedAt: true, 
  createdAt: true 
});
export const insertAttendanceRecordSchema = createInsertSchema(attendanceRecords).omit({ 
  id: true, 
  verifiedAt: true, 
  createdAt: true 
});
export const insertAttendanceAnomalySchema = createInsertSchema(attendanceAnomalies).omit({ 
  id: true, 
  resolvedAt: true, 
  createdAt: true 
});
export const insertMonthlyAttendanceSummarySchema = createInsertSchema(monthlyAttendanceSummary).omit({ 
  finalizedAt: true, 
  createdAt: true 
});
export const insertNotificationSchema = createInsertSchema(notifications).omit({ 
  id: true, 
  createdAt: true 
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Department = typeof departments.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type Employee = typeof employees.$inferSelect;
export type OvertimeRequest = typeof overtimeRequests.$inferSelect;
export type OvertimeRequestEmployee = typeof overtimeRequestEmployees.$inferSelect;
export type Approval = typeof approvals.$inferSelect;
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type AttendanceAnomaly = typeof attendanceAnomalies.$inferSelect;
export type MonthlyAttendanceSummary = typeof monthlyAttendanceSummary.$inferSelect;
export type Notification = typeof notifications.$inferSelect;

export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type InsertOvertimeRequest = z.infer<typeof insertOvertimeRequestSchema>;
export type InsertOvertimeRequestEmployee = z.infer<typeof insertOvertimeRequestEmployeeSchema>;
export type InsertApproval = z.infer<typeof insertApprovalSchema>;
export type InsertAttendanceRecord = z.infer<typeof insertAttendanceRecordSchema>;
export type InsertAttendanceAnomaly = z.infer<typeof insertAttendanceAnomalySchema>;
export type InsertMonthlyAttendanceSummary = z.infer<typeof insertMonthlyAttendanceSummarySchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
